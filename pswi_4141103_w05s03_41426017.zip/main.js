const greetingButton =
 document.querySelector('#greeting-button');
greetingButton.addEventListener('click', () => {
alert('Selamat Belajar Pengembangan Situs Web I!');
});

console.log('main.js berhasil dijalankan');

document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector("form");

    form.addEventListener("submit", function (event) {
        event.preventDefault();

        alert("Pendaftaran berhasil!");
    });
});
