Nama    : Michell P C Sihombing
NIM     : 41426017
Prodi   : DIV Teknologi Rekayasa Perangkat Lunak



1. tujuan : mempelajari tentang css grid untuk mengatur layout kartu kegiatan dan flexbox untuk mengatur isi satiap kartu

2. hasil pengujian pada lebar 320px, 768px, 1200px berhasil diuji dan navigasi menggunakan tombol tab berhasil diuji

3. Eror :
ada 3 eror pada style.css dimana pada baris ke20, 28, dan 59. Eror terjadi karena typo pada code dan tanda (;) tertinggal.

4. perubahan yang diganti : 
- mengganti container menjadi catalog.
- menggunakan grid responsif
- menggunakan class card untuk semua kegiatan

5. Penggunaan AI :
saya menggunakan AI untuk membantu mengarahkan dan memahami apa yang diinstruksikan pada modul week 5 sesi 3. saya menggunakan AI untuk membantu saya memperbaiki eror pada struktur code style.css. saya juga menggunakan AI dalam mencari fungsi display, grid-template-columns, auto-fit, dan minmax ().

fungsi :
- dislay: grid adalah mengatur elemen menjadi susunan berbentuk baris dan kolom
- grid-template-columns adalah menentukan jumlah dan ukuran kolom
- auto-fit adalah menyesuaikan jumlah kolom secara otomatis berdasarkan ruang yang tersedia
- minmax () adalah menentukan minimum dan maksimum suatu kolom