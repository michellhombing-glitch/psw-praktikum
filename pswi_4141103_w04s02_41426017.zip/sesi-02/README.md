Selector, Cascade, dan Box Model

Nama    : Michell P C Sihombing
NIM     : 41426017
Prodi   : DIV Teknologi Rekayasa Perangkat Lunak


asumsi :
sebelum memulai praktikum saya memikirkan selanjutnya akan mempelajari bagaimana cara mengdesain border  web yang saya buat sebelumnya.

- persiapan stylesheet :
(Awal Mendesain)
memasukkan code index week 1 dan disambung code index week 3. memasukkan <link rel="stylesheet" href="style.css"> sehingga terhubung ke style.css yang dibuat. 

(Periksa Network)
menguji "style.csss" sehingga di Network memuat "Failed/404" dan desain pada halaman web hilang.

(hasil setelah didaftar)
file:///D:/SEMESTER%201/Pengembangan%20Situs%20Web%201/week%204/pswi-week-4/sesi-02/index.html?nama=ee&telepon=08820128102&email=michell%40example.com&tiket=1&kode=001789&prodi=trpl&mode=luring&minat=THTML&catatan=se%0D%0A#


- selector dan class:
1. Menambahkan `class="card"` pada elemen `<form>` dan `class="notice"` pada elemen `<p>` petunjuk di `index.html`.
2. Menambahkan aturan `form.card` dan `.notice` di `style.css`
3. Memeriksa elemen menggunakan DevTools (tab Elements & Styles).
4. menghilangkan 
padding: 1rem;
margin-bottom: 1rem;
background: rgb(187, 203, 198);
border: 1px solid #ffffff;
border-radius: 50px;
Maka halaman webnya akan berantakan.


- hasil akhir :
hasil akhir yaitu saya sedikit mengerti untuk cara mendesain web dengan menggunakan bahasa C dengan struktur CSS, form.card, stylesheet, dan selector terarah.

- AI :
saya menggunakan ai pada saat terjadi eror ketika menggunakan validator.
yang eror yaitu, struktur code saya berantakan di head, body, dan main. pada gambar ke-1 week 1 saya membuat terlalu panjang dan imgae tidak keluar <img src="c:\Users\User\Downloads\Matius 7_7.jpg"> menjadi <img src="Matius7_7.jpg".


