Laporan Debugging (DevTools, HTTP, Debugging, dan Git Dasar)

Nama    : Michell P C Sihombing
NIM     : 41426017
Prodi   : DIV Teknologi Rekayasa Perangkat Lunak

1.Ketika jalur tautan pada <link rel="stylesheet" href="css/style.css"> sengaja diubah menjadi salah <link rel="stylesheet" href="css/style.csss">, gejala yang muncul adalah CSS tidak tampil sehingga halaman web menjadi polos tanpa desain maupun layout. 
2.Bukti dari masalah ini dapat dilihat dengan membuka Developer Tools di browser (tekan F12) pada tab Network atau Console, yang akan menampilkan pesan error "style.csss (failed)". 
3.Penyebab utama dari galat tersebut adalah adanya kesalahan penulisan ekstensi file pada atribut href yang mengakibatkan jalurnya menjadi keliru. 
4.Untuk melakukan perbaikan, Anda cukup mengubah kembali atribut href ke jalur yang benar, yaitu css/style.css. Setelah diperbaiki, hasil yang diperoleh adalah status kode akan berubah menjadi 200 (OK) dan tampilan halaman web akan kembali normal seperti semula.