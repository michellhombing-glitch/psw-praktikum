Nama      : Michell P C Sihombing
NIM       : 41426017
Prodi     : DIV Teknologi Rekayasa Perangkat Lunak

saya menggunakan AI untuk membantu saya dalam memahami setisp arti code yang ada :
1. srcset: menyediakan beberapa pilihan file gambar dan mengset sesuai dengan ukuran layar.
2. foto-320.jpg: gambar dengan lebar 320px
3. 320w : menyatakan lebar intrinsik gambar sebesar 320px
4. sizes : memberi tahu browser perkiraan lebar gambar yang akan ditampilkan di halaman
5. 50vw : gambar diperkirakan menggunakan 50% lebar viewport jika kondisi tersebut dipenuhi
6. 92vw : jika kondisi tidak terpenuhi, gambar diperkirakan menggunakan 92% lebar viewport
7. vw (viewport-width) : satuan berdasarkan lebar area tampilan browser


pada no 5 di modul code menjelaskan :
untuk mengatur ukuran tulisan dan jarak di dalam card agar menyesuaikan  dengan ukuran layar dan lebar container (fluid font dan container query)
1. clamp () : mengatur ukuran font secara fleksibel dengan batas minimum dan maksimum.
2. @container : menerapkan aturan css berdasarkan ukuran container.
3. container-type : menentukan container acuan.
4. .card-wrap : untuk mengubah lebar container tanpa mengubah viewport.

perbedaan query :
fluid font menyesuaikan ukuran tulisan berdasarkan layar, sedangkan container query menyesuaikan tampilan komponen berdasarkan ukuran container. container-type berfungsi menentukan container yang menjadi acuannya.

reduced motion berfungsi mengurangi atau menghilangkan animasi dna transisi pada website sesuai preferensi pengguna. tujuannya agar lebih nyaman diakses terutama pada pengguna yang sensitif pada gerakan di layar.
1. prefers-reduced-motion: reduce: memeriksa apakah pengguna memilih pengurangan gerakan melalui pengaturan perangkat atau browser.
2. transition: none; : menghilangkan efek transisi pada card 

- kasus normal : membuka halaman web pada ukuran layar normal. halaman web jelas dan rapi. terbukti berhasil-- 
- kasus batas : mengubah ukuran viewport menjadi lebih kecil dan besar. ukurannya sesuai dengan code yang dibuat. terbukti berhasil
- kasus gagal : mengaktifkan reduced motion untuk memeriksa pengurangan transisi. kode css prefers-reduced-motion.belum diuji

saya menggunakan transition: transform 0.3s ease;
.card:hover 
    transform: translateY(-15px);
    color: #12526d;
    background-color: #eff7ff;
saya menggunakan transition untuk mempercantik tampilan web saya.



validator style.css
tertulis :
> `Unrecognized at-rule @container`
penjelasan :
Pesan error tersebut muncul karena versi validator yang digunakan belum sepenuhnya memperbarui dukungannya terhadap fitur CSS modern, yaitu (`@container`). 
Secara standar dan teknis penulisan, kode CSS tersebut **sudah benar** dan telah didukung secara penuh oleh seluruh *browser* modern saat ini. Anda dapat mengabaikan pesan error dari validator tersebut dengan aman.

