Nama    : Michell P C Sihombing
NIM     : 41426017
Prodi   : DIV Tekonologi Rekayasa Perangkat Lunak


saya belajar mengenai Navigasi dan Card dengan Flexbox. website ini dibuat menggunakan html dan css dengan tema komunitas web mahasiswa. 

1. Pengujian 360px :
    Tampilan lebar 360px terlihat rapi pada website, terlihat pada folder bukti. kode pada css yaitu flex-wrap: wrap dan min-widht: 0 yang digunakan untuk menyesuaikan ruang yang tersedia agar tidak melewati garis kartu.


2. Pengujian 1200px :
    Tampilan lebar 1200px terlihat rapi pada website, terlihat pada folder  bukti. kode yang digunakan pada css yaitu max-width dan margin: 0 auto pada css membatasi lebar dan menempatlan halaman di tengah.

3. Empat kartu :
    Keempat kartu terlihat pada lebar 360px di halaman kegiatan. Tujuan ini dibuat agar memastikan seluruh kartu dapat terlihat ketika membuka web kegiatan tanpa terpotong. kode yang digunakan yaitu flex dan flex-wrap pada css yang digunakan untuk mengatur ukuran kartu berpindah ke baris berikutnya sesuai ruang yang tersedia.

4. Judul panjang :
    Judul tetap pada kartu dan tidak memanjang kesamping/lewat dari batas kartu. kode nya overflow-warp: anywhere pada css membantu memotong teks panjang agar tidak melewati batas garis kartu.

5. Menguji besar 200%
    Website diuji dengan pembesaran layar hingga 200% untuk memeriksa keterbacaan teks. Hasil pengujian digunakan untuk memastikan teks tetap terlihat dan tidak terpotong. terlihat pada bukti.

6. Penggunaan AI
Saya menggunakan AI untuk membantu memahami materi dan instruksi pada modul. Saya juga memanfaatkan AI untuk memperjelas pemahaman dalam mengerjakan tugas. 
