Nama    : Michell P C Sihombing
NIM     : 41426017
Prodi   : DIV Teknologi Rekayasa Perangkat Lunak


1. kasus 1200px : katalog tampil dengan dua kolom dan rapi, maka hasil pengujian berhasil

2. kasus batas 320px : ubah viewport menjadi 320px, kotak putih tidak ada scroll horizontal, maka berhasil

3. breakpoint : uji pada 767px, 768px, 769px layout berubah sesuai kondisi media query

4. kasus zoom 200% : perbesar tampilan browser menjadi 200%,konten terbaca dan tidak terpotong.

5. kasus keyboard : tekan tombol tab berulang kali dan fokus terlihat dan navigasi dapat digunakan

6. kasus gagal : menambahkan width = 900% pada sebuah element, overflow muncul keluar dari box. untuk  memperbaikinya gunakan ukuran yang fleksibel yaitu max-width: 100%

7. pada validasi html ada kesalahan yaitu terdapat 2 main pada struktur html nya, dan saya mengubah main yang kedua menjadi <section> </section>.


saya menggunakan Ai untuk memahami apa kegunaan dari code tertentu :
1. viewport : menampilkan area layar untuk halaman web
2. breakpoint : menentukan batas ukuran layar untuk perubahan layout
3. media query : aturan css yang menerapkan gaya tertentu jika kondisi yang ditentukan terpenuhi
- @media : menulai aturan media query
- min-width : menentukan lebar minimun
- max-width : menentukan lebar maximal
- .catalog : elemen yang akan diubah
- 48rem : batas lebar yang digunakan
- repeat(2, 1fr) : membeuat dua kolom dengan lebar yang sama
4. mobile-first : pendekatan membuat tampilan untuk layar kecil terlebih dahulu, kemudian menyesuaikan untuk layar yang lebih besar. (website bisa sigunakan pada layar kecil tanpa berpatokan pada layar desktop)
5. css grid : sistem layout untuk mengatur elemen dalam bentuk baris dan kolom
- dislapy: gird: mengaktifkan css grid
- gap: 1rem: memberi jarak antarelemen
- grid-template-columns: menentukan jumlah dan ukuran kolom
6. overflow : terjadi ketika isi atau elemen terlalu besar sehingga melampaui wadahnya.
