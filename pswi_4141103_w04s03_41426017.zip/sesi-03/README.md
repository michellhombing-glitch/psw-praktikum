Unit, Tipografi, dan Sistem Gaya Dasar

Nama    : Michell P C Sihombing
NIM     : 41426017
Prodi   : DIV Teknologi Rekayasa Perangkat Lunak

1. Reset ukuran kotak
disini menjelaskan bahwa apakah ukuran kotak/main dapat menyesuaikan ukuran layar. width menentukan lebar elemen, sedangkan max-width memberikan batas maksimal lebar elemen. Jadi, walaupun layar semakin besar, elemen tidak akan terus membesar melewati nilai max-width. hasilnya ukuran main dapat meyesuaikan ukuran layar. (validator style aman sukses)

2. Token warna dan jarak
disini diajari --brand CSS dapat digunakan secara berulang kali. uji coba mengubah --brand satu kali pada background. hasilnya yaitu tombol "tampilkan salam" dan "daftar" berubah dengan menambahkan  
button {
    background: var(--brand);
    color: var(--ink);
}
(validator style aman sukses)

3. Tipografi dan unit
membandingkan 1 rem dengan 1,5 rem bertujuan untuk melihat perbedaan ukuran, ketika menggunakan rem apakah 1,5 lebih besar dari pada 1 rem. saya menggunakan 1.5 rem hasil telah saya uji adalah teks jadi lebih besar dari pada 1 rem dan teks tidak terpotong setelah di perbesar 200%. (validator style aman sukses)

4. Organisasi dan audit
menyusun CSS menjadi base, wadah, komponen, dan interaction states. validator style aman sukses. memberikan tanda visual berwarna merah ketika tombol sedang mendapatkan fokus (mengklik Tab).

5. Latihan mandiri dan matriks uji
Kasus                               Harapan
Zoom 200%                           Konten tetap tersedia
Token brand diganti                 Komponen terkait berubah
Tab                                 Fokus terlihat
Teks panjang                        Tidak terpotong

6. Troubleshooting dan AI Use Statement
saya menggunakan Ai untuk membantu saya memahami modul yang dikasih pada week 4 sesi 3. 

secara keseluruhan, CSS ini digunakan untuk mengatur tampilan sebuah halaman web menjadi lebih rapi dan menarik. setiap bagian seperti body, header, main, judul, tombol, input, fieldset, dan legend diberikan pengaturan sesuai dengan fungsinya.